-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "forecastYears" INTEGER NOT NULL DEFAULT 5;
