-- AlterTable
ALTER TABLE "BalanceYear" ADD COLUMN     "investments" DOUBLE PRECISION NOT NULL DEFAULT 0;
